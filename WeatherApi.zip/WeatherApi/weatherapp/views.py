from django.shortcuts import render

import urllib.request
import json

def index(request):
    if(request.method=='POST'):
        city=request.POST['city']
        source=urllib.request.urlopen('https://api.openweathermap.org/data/2.5/weather?q='
        +city+'&units=metric&appid=5426933cb5ea85e8b96ec08bc0e6423c').read()
        print(source)
        res_data=json.loads(source)
        data={
            "country_code":str(res_data["sys"]["country"]),

            "coordinate":str(res_data["coord"]["lon"])+","+str(res_data["coord"]["lat"]),
            "temp":str(res_data['main']['temp'])+' C',
            "pressure":str(res_data['main']['pressure']),
            "humidity":str(res_data['main']['humidity']),

            "main":str(res_data['weather'][0]['main']),
            "description":str(res_data['weather'][0]['description']),
            "icon":str(res_data['weather'][0]['icon'])
        }
        print(data)
    else:
        data={}
    return render(request,'main/index.html',data)

# Create your views here.
